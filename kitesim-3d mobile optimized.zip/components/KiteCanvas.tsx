import React, { useRef, useEffect, useCallback, useState, useMemo } from 'react';
import type { Vector2D, Kite, AIPersonality, PlayerKiteInfo } from '../types';
import type { WeatherType } from '../App';
import { updateKiteAI } from '../ai/kite-ai-handler';

interface KiteCanvasProps {
  windSpeed: number;
  kiteColor: string;
  score: number;
  setScore: React.Dispatch<React.SetStateAction<number>>;
  difficulty: number;
  weather: WeatherType;
  isPaused: boolean;
  isMuted: boolean;
  gamepadIndex: number | null;
}

const RealisticCloud = ({ style }: { style: React.CSSProperties }) => (
    <div className="absolute" style={style}>
      <div className="absolute w-48 h-24 bg-white/40 rounded-full blur-xl -translate-x-1/4"></div>
      <div className="absolute w-32 h-16 bg-white/40 rounded-full blur-xl translate-x-1/4 translate-y-1/4"></div>
      <div className="absolute w-40 h-20 bg-white/25 rounded-full blur-2xl top-0 left-0"></div>
    </div>
);

const Stars = () => {
  const stars = useMemo(() => Array.from({ length: 150 }).map((_, i) => ({
      id: i, top: `${Math.random() * 100}%`, left: `${Math.random() * 100}%`,
      animationDuration: `${Math.random() * 2 + 1}s`, animationDelay: `${Math.random() * 2}s`,
      transform: `scale(${Math.random() * 0.5 + 0.5})`,
  })), []);
  return <div className="absolute inset-0">{stars.map(star => <div key={star.id} className="absolute bg-white rounded-full w-0.5 h-0.5 animate-twinkle" style={{ ...star }} />)}</div>;
};

const WindFlashes = ({ wind }: { wind: Vector2D }) => {
    const flashes = useMemo(() => Array.from({length: 5}).map((_, i) => ({
        id: i, top: `${Math.random() * 100}%`, left: `${Math.random() * 100}%`,
        duration: `${Math.random() * 0.5 + 0.3}s`, delay: `${Math.random() * 1}s`,
    })), []);
    const angle = Math.atan2(wind.y, wind.x) * (180 / Math.PI);
    return (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {flashes.map(f => (
                <div key={f.id} className="absolute bg-white/20 w-40 h-0.5 rounded-full animate-wind-flash"
                     style={{
                        top: f.top, left: f.left, transform: `rotate(${angle}deg)`,
                        animationDuration: f.duration, animationDelay: f.delay
                    }}/>
            ))}
        </div>
    );
};

const Rain = ({ wind }: { wind: Vector2D }) => {
    const drops = useMemo(() => Array.from({ length: 70 }).map((_, i) => ({
        id: i, left: `${Math.random() * 110 - 5}%`,
        duration: `${Math.random() * 0.5 + 0.3}s`, delay: `${Math.random() * 2}s`,
    })), []);
    const angle = Math.atan2(wind.y, wind.x) * (180 / Math.PI) + 90;
    return (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {drops.map(d => (
                <div key={d.id} className="absolute bg-gradient-to-b from-white/0 to-white/40 w-0.5 h-20 animate-rain"
                     style={{
                        left: d.left, transform: `rotate(${angle}deg)`,
                        animationDuration: d.duration, animationDelay: d.delay
                    }}/>
            ))}
        </div>
    );
};


const clouds = [
  { top: '10%', left: '5%', scale: 1.5, speed: 0.08 }, { top: '25%', left: '80%', scale: 1.2, speed: 0.06 }, { top: '70%', left: '30%', scale: 1.8, speed: 0.1 },
  { top: '5%', left: '50%', scale: 0.8, speed: 0.03 }, { top: '50%', left: '10%', scale: 1, speed: 0.04 }, { top: '85%', left: '90%', scale: 1.1, speed: 0.05 }, { top: '40%', left: '-20%', scale: 1.3, speed: 0.07 },
];
const enemyColors = ['#0099ff', '#ffcc00', '#25d366', '#9b59b6'];
const GRAVITY = 0.08;

const weatherBackgrounds: Record<WeatherType, string> = {
  sunny: "from-sky-400 via-sky-600 to-indigo-800",
  sunset: "from-orange-400 via-pink-500 to-indigo-800",
  stormy: "from-slate-700 via-slate-800 to-black",
  night: "from-indigo-900 to-black",
};

export function KiteCanvas({ windSpeed, kiteColor, score, setScore, difficulty, weather, isPaused, isMuted, gamepadIndex }: KiteCanvasProps): JSX.Element {
  const canvasRef = useRef<HTMLDivElement>(null);
  const animationFrameId = useRef<number | null>(null);
  
  const playerKite = useRef({
    pos: { x: 300, y: 200 }, vel: { x: 0, y: 0 }, isKicking: false,
    tail: Array.from({ length: 10 }, () => ({ x: 300, y: 200 }))
  });
  const mousePos = useRef<Vector2D>({ x: 300, y: 200 });
  const wind = useRef<Vector2D>({ x: 0.5, y: -0.2 });
  const frameCount = useRef(0);
  
  const enemyKites = useRef<Kite[]>([]);
  const [scorePop, setScorePop] = useState(false);

  const keyboardKick = useRef(false);
  const wasKicking = useRef(false);
  const lastInputType = useRef<'mouse' | 'gamepad' | 'touch'>('mouse');
  const spawnTimeoutId = useRef<number | null>(null);
  const lastTapTime = useRef(0);
  const kickRequestTime = useRef(0);

  const audio = useRef<{ [key: string]: HTMLAudioElement }>({});
  useEffect(() => {
    const windAudio = new Audio('https://cdn.freesound.org/previews/476/476849_6935003-lq.mp3');
    windAudio.loop = true;
    windAudio.volume = 0;

    const rainAudio = new Audio('https://cdn.freesound.org/previews/34/34065_28216-lq.mp3');
    rainAudio.loop = true;
    rainAudio.volume = 0;

    audio.current = {
        wind: windAudio,
        whoosh: new Audio('https://cdn.freesound.org/previews/60/60013_71257-lq.mp3'),
        farWhoosh: new Audio('https://cdn.freesound.org/previews/683/683096_6253486-lq.mp3'),
        cut: new Audio('https://cdn.freesound.org/previews/810/810095_6951162-lq.mp3'), // Not in user request, keeping original
        score: new Audio('https://cdn.freesound.org/previews/456/456965_6456158-lq.mp3'),
        rain: rainAudio,
        thunder: new Audio('https://cdn.freesound.org/previews/527/527664_7707368-lq.mp3'),
        thunderHeavy: new Audio('https://cdn.freesound.org/previews/39/39827_28216-lq.mp3'),
    };

    Object.values(audio.current).forEach(a => {
        a.load();
        a.volume = 1; // Default volume
    });
    // Set loop audio initial volumes
    audio.current.wind.volume = 0;
    audio.current.rain.volume = 0;
  }, []);

  useEffect(() => {
    const windAudio = audio.current.wind;
    const rainAudio = audio.current.rain;
    if (windAudio && rainAudio) {
      if (!isPaused && !isMuted) {
        if(weather === 'stormy') {
            windAudio.volume = Math.min(windSpeed * 0.3 + 0.3, 1);
            rainAudio.play().catch(e => console.error("Audio play failed:", e));
            rainAudio.volume = 0.5;
        } else {
            windAudio.volume = Math.min(windSpeed * 0.3, 1);
            if (!rainAudio.paused) {
              rainAudio.volume = 0;
              setTimeout(() => rainAudio.pause(), 300);
            }
        }
        windAudio.play().catch(e => console.error("Audio play failed:", e));
      } else {
        windAudio.volume = 0;
        rainAudio.volume = 0;
      }
    }
  }, [isPaused, isMuted, windSpeed, weather]);

  const playSound = useCallback((sound: string, volume = 1.0) => {
    if (!isMuted && audio.current[sound]) {
        const soundEl = audio.current[sound];
        soundEl.currentTime = 0;
        soundEl.volume = Math.min(1, Math.max(0, volume)); // Clamp volume
        soundEl.play().catch(e => console.error(`Sound effect '${sound}' failed:`, e));
    }
  }, [isMuted]);

  const vibrateController = useCallback((duration: number, weakMagnitude = 1.0, strongMagnitude = 1.0) => {
    if (isPaused || isMuted || gamepadIndex === null) return;
    const gamepad = navigator.getGamepads()[gamepadIndex];
    if (gamepad && gamepad.vibrationActuator) {
        gamepad.vibrationActuator.playEffect('dual-rumble', {
            startDelay: 0,
            duration: duration,
            weakMagnitude: weakMagnitude,
            strongMagnitude: strongMagnitude,
        }).catch(e => console.error("Vibration failed:", e));
    }
  }, [gamepadIndex, isPaused, isMuted]);

  useEffect(() => {
    const spawnKites = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const canvasWidth = canvas.clientWidth;
      const canvasHeight = canvas.clientHeight;
      const numToSpawn = 1 + Math.floor(Math.random() * 4); // 1 to 4 kites

      const container = document.getElementById('kite-svg-container');
      const stringContainer = document.getElementById('string-svg-container');
      if (!container || !stringContainer) return;

      for (let i = 0; i < numToSpawn; i++) {
        const spawnFromLeft = Math.random() > 0.5;
        const pos = { x: spawnFromLeft ? 50 : canvasWidth - 50, y: canvasHeight - (Math.random() * 50 + 20) };
        const personalities: AIPersonality[] = ['peaceful', 'aggressive', 'clever'];
        const personality = personalities[Math.floor(Math.random() * personalities.length)];

        const newKite: Kite = {
          id: Date.now() + i, pos,
          vel: { x: (spawnFromLeft ? 1 : -1) * 2, y: -5 }, lift: { x: 0, y: 0 }, drag: 0.97,
          color: enemyColors[Math.floor(Math.random() * enemyColors.length)],
          isCut: false, aiState: 'roaming', targetId: null, roamTarget: null, isKicking: false, kickCooldown: 0,
          tail: Array.from({ length: 8 }, () => ({ ...pos })),
          aiPersonality: personality, spawnState: 'spawning', spawnTimer: (3 + Math.random() * 2) * 60,
        };
        enemyKites.current.push(newKite);

        const svgNS = "http://www.w3.org/2000/svg";
        const kiteSvg = document.createElementNS(svgNS, 'svg');
        kiteSvg.setAttribute('width', '50'); kiteSvg.setAttribute('height', '50');
        kiteSvg.setAttribute('viewBox', '0 0 100 100');
        kiteSvg.classList.add('absolute', 'enemy-kite'); kiteSvg.id = `enemy-kite-${newKite.id}`;
        kiteSvg.style.willChange = 'transform'; kiteSvg.style.zIndex = '9';
        kiteSvg.innerHTML = `<g><polygon points="50,0 100,50 50,100 0,50" fill="${newKite.color}" stroke="rgba(0,0,0,0.4)" stroke-width="4"/><line x1="50" y1="0" x2="50" y2="100" stroke="rgba(0,0,0,0.4)" stroke-width="2" /><line x1="0" y1="50" x2="100" y2="50" stroke="rgba(0,0,0,0.4)" stroke-width="2" /></g>`;
        container.appendChild(kiteSvg);

        const tailPath = document.createElementNS(svgNS, 'path');
        tailPath.id = `enemy-tail-${newKite.id}`;
        tailPath.setAttribute('stroke', newKite.color); tailPath.setAttribute('stroke-width', '2');
        tailPath.setAttribute('fill', 'none'); tailPath.setAttribute('opacity', '0.7');
        tailPath.classList.add('enemy-tail');
        stringContainer.appendChild(tailPath);
        
        const stringPath = document.createElementNS(svgNS, 'path');
        stringPath.id = `enemy-string-${newKite.id}`;
        stringPath.setAttribute('stroke', 'rgba(255, 255, 255, 0.2)'); stringPath.setAttribute('stroke-width', '1.5');
        stringPath.setAttribute('fill', 'none'); stringPath.classList.add('enemy-string');
        stringContainer.appendChild(stringPath);
      }
    };
    
    const scheduleNextSpawn = () => {
      if (spawnTimeoutId.current) clearTimeout(spawnTimeoutId.current);
      const delay = (30 + Math.random() * 30) * 1000;
      spawnTimeoutId.current = window.setTimeout(() => {
        spawnKites();
        scheduleNextSpawn();
      }, delay);
    };

    if (!isPaused) {
      enemyKites.current.forEach(k => {
          document.getElementById(`enemy-kite-${k.id}`)?.remove();
          document.getElementById(`enemy-tail-${k.id}`)?.remove();
          document.getElementById(`enemy-string-${k.id}`)?.remove();
      });
      enemyKites.current = [];
      scheduleNextSpawn();
    } else {
      if (spawnTimeoutId.current) clearTimeout(spawnTimeoutId.current);
    }

    return () => { if (spawnTimeoutId.current) clearTimeout(spawnTimeoutId.current); };
  }, [isPaused, difficulty]);
  
  const handleMouseMove = useCallback((e: MouseEvent) => { if (canvasRef.current) { lastInputType.current = 'mouse'; const rect = canvasRef.current.getBoundingClientRect(); mousePos.current = { x: e.clientX - rect.left, y: e.clientY - rect.top }; } }, []);
  const handleKeyDown = useCallback((e: KeyboardEvent) => { if (e.key === 'e' || e.key === 'E') { keyboardKick.current = true; } }, []);
  const handleKeyUp = useCallback((e: KeyboardEvent) => { if (e.key === 'e' || e.key === 'E') keyboardKick.current = false; }, []);

  const handleTouchStart = useCallback((e: TouchEvent) => {
    e.preventDefault();
    if (!canvasRef.current) return;
    lastInputType.current = 'touch';

    const now = Date.now();
    if (now - lastTapTime.current < 300) { // 300ms for double tap
        kickRequestTime.current = now;
    }
    lastTapTime.current = now;

    const rect = canvasRef.current.getBoundingClientRect();
    mousePos.current = { 
        x: e.touches[0].clientX - rect.left, 
        y: e.touches[0].clientY - rect.top 
    };
  }, []);

  const handleTouchMove = useCallback((e: TouchEvent) => {
    e.preventDefault();
    if (!canvasRef.current || e.touches.length === 0) return;
    const rect = canvasRef.current.getBoundingClientRect();
    mousePos.current = { 
        x: e.touches[0].clientX - rect.left, 
        y: e.touches[0].clientY - rect.top 
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) {
        canvas.addEventListener('mousemove', handleMouseMove);
        canvas.addEventListener('touchstart', handleTouchStart, { passive: false });
        canvas.addEventListener('touchmove', handleTouchMove, { passive: false });
    }
    window.addEventListener('keydown', handleKeyDown); window.addEventListener('keyup', handleKeyUp);
    return () => { 
      if (canvas) {
        canvas.removeEventListener('mousemove', handleMouseMove);
        canvas.removeEventListener('touchstart', handleTouchStart);
        canvas.removeEventListener('touchmove', handleTouchMove);
      }
      window.removeEventListener('keydown', handleKeyDown); window.removeEventListener('keyup', handleKeyUp); 
    }
  }, [handleMouseMove, handleKeyDown, handleKeyUp, handleTouchStart, handleTouchMove]);
  
  const animate = useCallback(() => {
    animationFrameId.current = requestAnimationFrame(animate);
    const canvas = canvasRef.current;
    if (!canvas || isPaused) return; 
    
    const gamepad = gamepadIndex !== null ? navigator.getGamepads()[gamepadIndex] : null;

    if (lastInputType.current === 'gamepad' || lastInputType.current === 'touch') {
        canvas.style.cursor = 'none';
    } else {
        canvas.style.cursor = '';
    }

    frameCount.current++;
    const canvasWidth = canvas.clientWidth; const canvasHeight = canvas.clientHeight;
    const isStormy = weather === 'stormy';

    if(isStormy && frameCount.current % 300 === 0 && Math.random() < 0.3) { 
        playSound(Math.random() < 0.6 ? 'thunder' : 'thunderHeavy');
    }
    if(frameCount.current % (isStormy ? 120 : 240) === 0) { wind.current.x = (Math.random() - 0.5) * (isStormy ? 3 : 2); wind.current.y = (Math.random() - 0.7) * (isStormy ? 1.2 : 0.8); }
    const gust = { x: (Math.random() - 0.5) * (isStormy ? 0.5 : 0.2), y: (Math.random() - 0.5) * (isStormy ? 0.5 : 0.2) };
    const windForce: Vector2D = { x: (wind.current.x + gust.x) * windSpeed, y: (wind.current.y + gust.y) * windSpeed * 0.5 };
    
    const pKite = playerKite.current;
    
    if (gamepad) {
        const DEADZONE = 0.15;
        const axisX = gamepad.axes[0] ?? 0;
        const axisY = gamepad.axes[1] ?? 0;

        if (Math.hypot(axisX, axisY) > DEADZONE) {
            lastInputType.current = 'gamepad';
            mousePos.current = { 
                x: pKite.pos.x + axisX * 250, 
                y: pKite.pos.y + axisY * 250 
            };
        }
    }

    const gamepadKick = gamepad?.buttons[2]?.pressed ?? false;
    const tapKick = (Date.now() - kickRequestTime.current) < 250; // 250ms kick duration
    const totalKick = keyboardKick.current || gamepadKick || tapKick;

    if (totalKick && !wasKicking.current) {
        playSound('whoosh');
        vibrateController(100, 0.4, 0.2);
    }
    wasKicking.current = totalKick;
    pKite.isKicking = totalKick;


    const dx = mousePos.current.x - pKite.pos.x; const dy = mousePos.current.y - pKite.pos.y;
    const pullForce: Vector2D = { x: dx * 0.005, y: dy * 0.005 };
    
    const kiteAngle = Math.atan2(pKite.vel.y, pKite.vel.x);
    const windAngle = Math.atan2(windForce.y, windForce.x);
    const angleDiff = Math.abs(windAngle - kiteAngle);
    const liftMagnitude = Math.sin(angleDiff) * 0.2;
    const lift = { x: -Math.sin(kiteAngle) * liftMagnitude, y: Math.cos(kiteAngle) * liftMagnitude };

    pKite.vel.x += pullForce.x + windForce.x + lift.x;
    pKite.vel.y += pullForce.y + windForce.y + lift.y + GRAVITY;
    if (pKite.isKicking) { pKite.vel.x += dx * 0.01; pKite.vel.y += dy * 0.01; }
    
    pKite.vel.x *= 0.95; pKite.vel.y *= 0.95;
    pKite.pos.x += pKite.vel.x; pKite.pos.y += pKite.vel.y;

    if (pKite.pos.x < 25) { pKite.pos.x = 25; pKite.vel.x *= -0.5; }
    if (pKite.pos.x > canvasWidth - 25) { pKite.pos.x = canvasWidth - 25; pKite.vel.x *= -0.5; }
    if (pKite.pos.y < 25) { pKite.pos.y = 25; pKite.vel.y *= -0.5; }
    if (pKite.pos.y > canvasHeight - 25) { pKite.pos.y = canvasHeight - 25; pKite.vel.y *= -0.5; }

    let lastPoint = pKite.pos;
    pKite.tail.forEach(point => {
        const pdx = lastPoint.x - point.x; const pdy = lastPoint.y - point.y;
        const dist = Math.hypot(pdx, pdy);
        const newX = lastPoint.x - (pdx / dist) * 10; const newY = lastPoint.y - (pdy / dist) * 10;
        point.x += (newX - point.x) * 0.5; point.y += (newY - point.y) * 0.5;
        lastPoint = point;
    });

    const playerKiteData: PlayerKiteInfo = { id: -1, pos: pKite.pos, vel: pKite.vel, isKicking: pKite.isKicking, isCut: false };
    
    enemyKites.current = enemyKites.current.filter(k => {
      if(k.pos.y > canvasHeight + 200) {
        document.getElementById(`enemy-kite-${k.id}`)?.remove();
        document.getElementById(`enemy-tail-${k.id}`)?.remove();
        document.getElementById(`enemy-string-${k.id}`)?.remove();
        return false;
      }
      return true;
    });

    for(const enemy of enemyKites.current) {
      if (enemy.isCut) {
          enemy.vel.y += GRAVITY * 1.5; enemy.vel.x += windForce.x * 0.5;
      } else if (enemy.spawnState === 'spawning') {
          enemy.vel.y -= 0.2;
          enemy.vel.x += (canvasWidth / 2 - enemy.pos.x) * 0.0005;
          enemy.vel.y *= 0.98; enemy.vel.x *= 0.98;
          enemy.spawnTimer--;
          if (enemy.spawnTimer <= 0) {
            enemy.spawnState = 'active';
          }
      } else { // Active AI
          const aiContext = {
              difficulty,
              canvasWidth,
              canvasHeight,
              playSound,
          };
          const aiForces = updateKiteAI(enemy, playerKiteData, aiContext);

          const eKiteAngle = Math.atan2(enemy.vel.y, enemy.vel.x);
          const eAngleDiff = Math.abs(windAngle - eKiteAngle);
          const eLiftMag = Math.sin(eAngleDiff) * 0.2;
          enemy.lift = { x: -Math.sin(eKiteAngle) * eLiftMag, y: Math.cos(eKiteAngle) * eLiftMag };

          enemy.vel.x += windForce.x + aiForces.pull.x + enemy.lift.x + aiForces.boundary.x;
          enemy.vel.y += windForce.y + aiForces.pull.y + enemy.lift.y + GRAVITY + aiForces.boundary.y;
      }
      enemy.vel.x *= enemy.drag; enemy.vel.y *= enemy.drag;
      enemy.pos.x += enemy.vel.x; enemy.pos.y += enemy.vel.y;
      
      let lastTailPoint = enemy.pos;
      enemy.tail.forEach(point => {
          const pdx = lastTailPoint.x - point.x; const pdy = lastTailPoint.y - point.y;
          const dist = Math.hypot(pdx, pdy); const segLength = 8;
          if (dist > 0) {
            const newX = lastTailPoint.x - (pdx / dist) * segLength; const newY = lastTailPoint.y - (pdy / dist) * segLength;
            point.x += (newX - point.x) * 0.5; point.y += (newY - point.y) * 0.5;
          }
          lastTailPoint = point;
      });

      const playerDist = Math.hypot(enemy.pos.x - playerKite.current.pos.x, enemy.pos.y - playerKite.current.pos.y);
      if (!enemy.isCut && enemy.spawnState === 'active' && playerDist > 450 && frameCount.current % 240 === (enemy.id % 240) && Math.random() < 0.15) {
          const volume = Math.max(0.1, 1 - (playerDist - 450) / 800);
          playSound('farWhoosh', volume * 0.6);
      }
    }

    let scoreGained = 0;
    const allKitesForCollision = [playerKiteData, ...enemyKites.current];
    for (const attacker of allKitesForCollision) {
      if (!attacker.isKicking) continue;
      for (const target of enemyKites.current) {
        if (attacker.id === target.id || target.isCut) continue;
        const dist = Math.hypot(attacker.pos.x - target.pos.x, attacker.pos.y - target.pos.y);
        if (dist < 50) {
          target.isCut = true; target.drag = 0.98; playSound('cut');
          vibrateController(250, 0.9, 0.9);
          if(attacker.id === -1) { scoreGained++; }
        }
      }
    }
    if (scoreGained > 0) {
      setScore(s => s + scoreGained); setScorePop(true); playSound('score'); 
      vibrateController(150, 0.5, 0.5);
      setTimeout(() => setScorePop(false), 300);
    }
    if (weather !== 'night') {
        canvas.querySelectorAll('.cloud-element').forEach((cloud, index) => {
          const cloudData = clouds[index % clouds.length]; let currentLeft = parseFloat((cloud as HTMLElement).style.left);
          currentLeft += cloudData.speed * windSpeed; if(currentLeft > 120) currentLeft = -20;
          (cloud as HTMLElement).style.left = `${currentLeft}%`;
        });
    }

    updatePlayerDOM(canvas, pKite, kiteColor);
    updateEnemiesDOM(canvas, enemyKites.current);

  }, [windSpeed, difficulty, setScore, kiteColor, isPaused, weather, playSound, gamepadIndex, vibrateController]);

  useEffect(() => {
    animationFrameId.current = requestAnimationFrame(animate);
    return () => { if(animationFrameId.current) cancelAnimationFrame(animationFrameId.current); };
  }, [animate]);

  return (
    <div ref={canvasRef} className={`w-full h-full overflow-hidden bg-gradient-to-br relative ${weatherBackgrounds[weather]}`}>
        <style>{`
            .kicking { filter: drop-shadow(0 0 8px #ffffff) drop-shadow(0 0 16px ${kiteColor}); }
            .score-pop { animation: pop 0.3s ease-out; }
            @keyframes pop { 0% { transform: scale(1); } 50% { transform: scale(1.3); text-shadow: 0 0 15px #fff; } 100% { transform: scale(1); } }
            @keyframes twinkle { 0%, 100% { opacity: 0.5; } 50% { opacity: 1; } }
            .animate-twinkle { animation: twinkle linear infinite; }
            @keyframes wind-flash { 0% { transform: translateX(-100%) scaleX(0.5); opacity: 0; } 50% { opacity: 0.7; } 100% { transform: translateX(100%) scaleX(1); opacity: 0; } }
            .animate-wind-flash { animation: wind-flash linear infinite; }
            @keyframes rain { 0% { transform: translateY(-100px); opacity: 0; } 50% { opacity: 1; } 100% { transform: translateY(120vh); opacity: 0; } }
            .animate-rain { animation: rain linear infinite; }
        `}</style>
        
        {weather === 'stormy' && <Rain wind={wind.current} />}
        {weather === 'night' ? <Stars /> : <WindFlashes wind={wind.current} />}

        <div className="absolute top-4 left-4 text-white font-bold z-30 text-shadow-lg">
            <span className={`text-4xl transition-all duration-300 ${scorePop ? 'score-pop' : ''}`}>{score}</span>
        </div>

        {weather !== 'night' && clouds.map((cloud, i) => (
             <div key={i} className="cloud-element absolute transition-all duration-1000 ease-linear" style={{ top: cloud.top, left: cloud.left, transform: `scale(${cloud.scale})` }}>
                <RealisticCloud style={{}}/>
             </div>
        ))}
      
        <div id="kite-svg-container" className="absolute inset-0 w-full h-full">
            <svg id="string-svg-container" width="100%" height="100%" className="absolute inset-0">
                <path id="player-string" stroke="rgba(255, 255, 255, 0.4)" strokeWidth="2" fill="none" />
            </svg>
            <div id="player-kite-wrapper" className="absolute" style={{ willChange: 'transform', zIndex: 11 }}>
                 <svg width="50" height="90" viewBox="0 0 100 180">
                    <path id="player-tail" stroke={kiteColor} strokeWidth="3" fill="none" opacity="0.8" />
                    <circle id="player-tail-bow-1" r="6" fill="#34d399" />
                    <circle id="player-tail-bow-2" r="6" fill="#f87171" />
                    <g className={playerKite.current.isKicking ? 'kicking' : ''} style={{transition: 'filter 0.1s ease-in-out'}}>
                        <polygon points="50,0 100,50 50,100 0,50" fill={kiteColor} stroke="rgba(0,0,0,0.5)" strokeWidth="4"/>
                        <line x1="50" y1="0" x2="50" y2="100" stroke="rgba(0,0,0,0.5)" strokeWidth="2" />
                        <line x1="0" y1="50" x2="100" y2="50" stroke="rgba(0,0,0,0.5)" strokeWidth="2" />
                        <circle cx="50" cy="50" r="5" fill="rgba(0,0,0,0.5)"/>
                    </g>
                </svg>
            </div>
        </div>
    </div>
  );
}

function updatePlayerDOM(
    canvas: HTMLDivElement,
    playerKite: { pos: Vector2D; vel: Vector2D, tail: Vector2D[], isKicking: boolean },
    kiteColor: string
) {
    const canvasHeight = canvas.clientHeight;

    const playerKiteWrapper = canvas.querySelector<HTMLElement>('#player-kite-wrapper');
    if (playerKiteWrapper) {
        const rotation = playerKite.vel.x * 5;
        const scale = 1 - (playerKite.pos.y / canvasHeight) * 0.4;
        playerKiteWrapper.style.transform = `translate(${playerKite.pos.x - 25}px, ${playerKite.pos.y - 45}px) rotate(${rotation}deg) scale(${scale})`;
        
        const kiteSVG = playerKiteWrapper.querySelector('svg');
        if(kiteSVG) {
            const group = kiteSVG.querySelector('g');
            if(group) group.style.filter = playerKite.isKicking ? `drop-shadow(0 0 8px #ffffff) drop-shadow(0 0 16px ${kiteColor})` : 'none';

            const tailPath = kiteSVG.querySelector<SVGPathElement>('#player-tail');
            const bow1 = kiteSVG.querySelector<SVGCircleElement>('#player-tail-bow-1');
            const bow2 = kiteSVG.querySelector<SVGCircleElement>('#player-tail-bow-2');
            
            if (tailPath && bow1 && bow2) {
                const tailPoints = [{x: 50, y: 100}, ...playerKite.tail.map(p => ({
                    x: 50 + (p.x - playerKite.pos.x),
                    y: 100 + (p.y - playerKite.pos.y)
                }))];
                const tailPathData = tailPoints.reduce((acc, p, i) => {
                    if(i === 0) return `M${p.x},${p.y}`;
                    const cp1 = tailPoints[i-1];
                    const x = (cp1.x + p.x) / 2;
                    const y = (cp1.y + p.y) / 2;
                    return `${acc} Q ${cp1.x},${cp1.y} ${x},${y}`;
                }, '');
                tailPath.setAttribute('d', tailPathData);

                const bow1Point = tailPoints[Math.floor(tailPoints.length / 2)];
                const bow2Point = tailPoints[tailPoints.length - 1];
                bow1.setAttribute('cx', `${bow1Point.x}`); bow1.setAttribute('cy', `${bow1Point.y}`);
                bow2.setAttribute('cx', `${bow2Point.x}`); bow2.setAttribute('cy', `${bow2Point.y}`);
            }
        }
    }

    const playerString = canvas.querySelector<SVGPathElement>('#player-string');
    if(playerString) {
        const handX = canvas.clientWidth / 2; const handY = canvasHeight + 150;
        const control1X = handX + (playerKite.pos.x - handX) * 0.2; const control1Y = handY - (handY - playerKite.pos.y) * 0.4;
        const control2X = handX + (playerKite.pos.x - handX) * 0.8; const control2Y = playerKite.pos.y + (handY - playerKite.pos.y) * 0.4;
        const pathData = `M${handX},${handY} C${control1X},${control1Y} ${control2X},${control2Y} ${playerKite.pos.x},${playerKite.pos.y}`;
        playerString.setAttribute('d', pathData);
    }
}

function updateEnemiesDOM(canvas: HTMLDivElement, enemies: Kite[]) {
    const canvasHeight = canvas.clientHeight;
    for (const enemy of enemies) {
        const kiteEl = document.getElementById(`enemy-kite-${enemy.id}`) as HTMLElement | null;
        if(kiteEl) {
            const rot = enemy.isCut ? Math.sin(Date.now() * 0.002) * 45 + enemy.vel.x * 5 : enemy.vel.x * 5;
            const s = 1 - (enemy.pos.y / canvasHeight) * 0.4;
            kiteEl.style.transform = `translate(${enemy.pos.x - 25}px, ${enemy.pos.y - 25}px) rotate(${rot}deg) scale(${s})`;
            kiteEl.style.opacity = enemy.isCut ? '0.8' : '1';
            const group = kiteEl.querySelector('g');
            if(group) group.style.filter = enemy.isKicking ? `drop-shadow(0 0 8px ${enemy.color})` : 'none';
        }

        // FIX: Correct type assertion for SVGPathElement
        const stringEl = document.getElementById(`enemy-string-${enemy.id}`) as unknown as SVGPathElement | null;
        if(stringEl) {
            if(enemy.isCut) {
                stringEl.setAttribute('d', '');
            } else {
                const handX = canvas.clientWidth / 2; const handY = canvas.clientHeight + 150;
                const c1X = handX + (enemy.pos.x - handX) * 0.2; const c1Y = handY - (handY - enemy.pos.y) * 0.4;
                const c2X = handX + (enemy.pos.x - handX) * 0.8; const c2Y = enemy.pos.y + (handY - enemy.pos.y) * 0.4;
                const path = `M${handX},${handY} C${c1X},${c1Y} ${c2X},${c2Y} ${enemy.pos.x},${enemy.pos.y}`;
                stringEl.setAttribute('d', path);
            }
        }
        
        // FIX: Correct type assertion for SVGPathElement
        const tailEl = document.getElementById(`enemy-tail-${enemy.id}`) as unknown as SVGPathElement | null;
        if(tailEl) {
            const tailPathData = [enemy.pos, ...enemy.tail].reduce((acc, p, i) => {
                if(i === 0) return `M${p.x},${p.y}`;
                return `${acc} L${p.x},${p.y}`;
            }, '');
            tailEl.setAttribute('d', tailPathData);
        }
    }
}