import React from 'react';

interface PauseMenuProps {
  onResume: () => void;
  onMenu: () => void;
  windSpeed: number;
  setWindSpeed: (speed: number) => void;
  kiteColor: string;
  setKiteColor: (color: string) => void;
  difficulty: number;
  setDifficulty: (level: number) => void;
  isMuted: boolean;
  setIsMuted: (muted: boolean) => void;
  focusedIndex: number;
  focusedColorIndex: number;
}

const colors = [
  '#ff0055', '#0099ff', '#ffcc00', '#25d366', '#9b59b6', '#e67e22',
];

const MuteIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon></svg>
);

const UnmuteIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>
);

export function PauseMenu({ 
    onResume,
    onMenu,
    windSpeed, 
    setWindSpeed,
    kiteColor,
    setKiteColor,
    difficulty,
    setDifficulty,
    isMuted,
    setIsMuted,
    focusedIndex,
    focusedColorIndex,
}: PauseMenuProps): JSX.Element {

  return (
    <div className="absolute inset-0 z-50 bg-black/50 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-black/40 backdrop-blur-lg rounded-2xl shadow-2xl p-6 border border-white/10 flex flex-col gap-4">
        <div className="flex justify-between items-center">
            <h2 className="text-3xl font-bold text-center text-white flex-grow">Paused</h2>
            <button onClick={() => setIsMuted(!isMuted)} className="text-white hover:text-sky-300 transition-colors focus:outline-none focus:ring-2 focus:ring-white rounded-full p-1" aria-label={isMuted ? 'Unmute' : 'Mute'}>
                {isMuted ? <UnmuteIcon /> : <MuteIcon />}
            </button>
        </div>
        
        <div className={`p-2 rounded-lg transition-all duration-200 ${focusedIndex === 0 ? 'ring-2 ring-yellow-400' : 'ring-2 ring-transparent'}`}>
          <label htmlFor="wind" className="block text-sm font-medium text-sky-200 mb-1">Wind Speed: {windSpeed.toFixed(2)}</label>
          <input
              id="wind" type="range" min="0" max="2" step="0.05"
              value={windSpeed} onChange={(e) => setWindSpeed(parseFloat(e.target.value))}
              className="w-full h-2 bg-black/40 rounded-lg appearance-none cursor-pointer accent-sky-500"
          />
        </div>

        <div className={`p-2 rounded-lg transition-all duration-200 ${focusedIndex === 1 ? 'ring-2 ring-yellow-400' : 'ring-2 ring-transparent'}`}>
          <label htmlFor="difficulty" className="block text-sm font-medium text-sky-200 mb-1">Hardness: {difficulty.toFixed(2)}</label>
          <input
              id="difficulty" type="range" min="0" max="1" step="0.05"
              value={difficulty} onChange={(e) => setDifficulty(parseFloat(e.target.value))}
              className="w-full h-2 bg-black/40 rounded-lg appearance-none cursor-pointer accent-red-500"
          />
        </div>

        <div className={`p-2 rounded-lg transition-all duration-200 ${focusedIndex === 2 ? 'ring-2 ring-yellow-400' : 'ring-2 ring-transparent'}`}>
          <label className="block text-sm font-medium text-sky-200 mb-2">Kite Color</label>
          <div className="flex gap-2 flex-wrap justify-center">
              {colors.map((color, index) => (
                  <button
                      key={color} onClick={() => setKiteColor(color)}
                      className={`w-10 h-10 rounded-full transition-all transform hover:scale-110 focus:outline-none 
                        ${kiteColor === color ? 'ring-2 ring-offset-2 ring-offset-black/20 ring-white' : ''}
                        ${focusedIndex === 2 && focusedColorIndex === index ? 'ring-4 ring-yellow-300 ring-offset-2 ring-offset-black/40' : ''}
                      `}
                      style={{ backgroundColor: color }} aria-label={`Set kite color to ${color}`}
                  />
              ))}
          </div>
        </div>
        
        <div className="flex flex-col gap-3 mt-4">
            <button
                onClick={onResume}
                className={`w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 px-4 rounded-md transition-colors duration-200 focus:outline-none ${focusedIndex === 3 ? 'ring-4 ring-yellow-400' : 'focus:ring-2 focus:ring-sky-400'}`}
            >
                Resume
            </button>
            <button
                onClick={onMenu}
                className={`w-full bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-md transition-colors duration-200 focus:outline-none ${focusedIndex === 4 ? 'ring-4 ring-yellow-400' : 'focus:ring-2 focus:ring-gray-400'}`}
            >
                Back to Main Menu
            </button>
        </div>

      </div>
    </div>
  );
}