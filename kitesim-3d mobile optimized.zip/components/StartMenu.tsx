import React from 'react';
import type { WeatherType } from '../App';

const KiteIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-sky-300">
        <path d="M12 22c-2 0-3.8-2.3-5-5 1.2-2.7 3-5 5-5s3.8 2.3 5 5c-1.2 2.7-3 5-5 5z"/>
        <path d="M12 2v4.5"/>
        <path d="M12 12l-8 3 8 3 8-3-8-3z"/>
    </svg>
);

const Logo = () => (
    <div className="flex flex-col items-center gap-3 text-center">
        <KiteIcon />
        <div>
            <h1 className="text-5xl font-bold tracking-wider text-white" style={{textShadow: '0 2px 10px rgba(0,0,0,0.5)'}}>KiteSim 3D</h1>
            <p className="text-md text-sky-200 -mt-1">An Interactive Flight Experience</p>
        </div>
    </div>
);


interface StartMenuProps {
    onStart: () => void;
    weather: WeatherType;
    setWeather: (weather: WeatherType) => void;
    focusedButtonIndex: number;
}

const weatherOptions: { id: WeatherType, name: string, bg: string, text: string }[] = [
    { id: 'sunny', name: 'Sunny', bg: 'bg-sky-500', text: 'text-white' },
    { id: 'sunset', name: 'Sunset', bg: 'bg-orange-500', text: 'text-white' },
    { id: 'stormy', name: 'Stormy', bg: 'bg-slate-600', text: 'text-white' },
    { id: 'night', name: 'Night', bg: 'bg-indigo-800', text: 'text-white' },
];

const weatherBackgrounds: Record<WeatherType, string> = {
  sunny: "from-sky-400 to-sky-700",
  sunset: "from-orange-400 to-pink-600",
  stormy: "from-slate-700 to-black",
  night: "from-indigo-900 to-black",
};

export function StartMenu({ onStart, weather, setWeather, focusedButtonIndex }: StartMenuProps): JSX.Element {
    return (
        <div className={`w-full h-full flex flex-col items-center justify-center bg-gradient-to-br p-8 transition-colors duration-500 ${weatherBackgrounds[weather]}`}>
            <div className="w-full max-w-md bg-black/30 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/10 flex flex-col items-center gap-8">
                <Logo />
                
                <div className="w-full">
                    <label className="block text-center text-lg font-medium text-sky-200 mb-3">Select Weather</label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {weatherOptions.map((option, index) => (
                            <button
                                key={option.id}
                                onClick={() => setWeather(option.id)}
                                className={`px-4 py-2 rounded-lg font-semibold transition-all duration-200 focus:outline-none ${focusedButtonIndex === index ? 'ring-4 ring-yellow-400' : 'focus:ring-2 focus:ring-offset-2 focus:ring-offset-black/30 ring-white'} ${weather === option.id ? `${option.bg} ${option.text} shadow-lg` : 'bg-black/30 hover:bg-black/50'}`}
                            >
                                {option.name}
                            </button>
                        ))}
                    </div>
                </div>

                <button
                    onClick={onStart}
                    className={`w-full bg-green-500 hover:bg-green-600 text-white font-bold text-xl py-3 px-6 rounded-lg transition-all duration-200 focus:outline-none shadow-lg transform hover:scale-105 ${focusedButtonIndex === 4 ? 'ring-4 ring-yellow-400' : 'focus:ring-2 focus:ring-offset-2 focus:ring-offset-black/30 ring-green-400'}`}
                >
                    Start Flying
                </button>
            </div>
        </div>
    );
}