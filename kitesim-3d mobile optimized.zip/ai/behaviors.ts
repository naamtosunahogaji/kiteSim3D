import type { Kite, Vector2D, PlayerKiteInfo } from '../types';

interface AIContext {
    difficulty: number;
    playSound: (sound: string) => void;
}

interface AIUpdateResult {
    aiPull: Vector2D;
    updatedKite: Partial<Kite>;
}

export const updateAggressiveAI = (enemy: Kite, player: PlayerKiteInfo, context: AIContext): AIUpdateResult => {
    const { difficulty, playSound } = context;
    let aiPull: Vector2D = { x: 0, y: 0 };
    let updatedKite: Partial<Kite> = {};

    const playerDist = Math.hypot(enemy.pos.x - player.pos.x, enemy.pos.y - player.pos.y);
    const detectionRange = 350 + difficulty * 150;
    
    const isAttacking = playerDist < detectionRange && !player.isCut;

    if (isAttacking) {
        updatedKite.aiState = 'attacking';
        updatedKite.targetId = player.id;
        
        const predictionFactor = 15 + difficulty * 15;
        const predictedX = player.pos.x + player.vel.x * predictionFactor;
        const predictedY = player.pos.y + player.vel.y * predictionFactor;
        const targetDx = predictedX - enemy.pos.x;
        const targetDy = predictedY - enemy.pos.y;

        aiPull.x = targetDx * 0.002 * (difficulty + 0.5);
        aiPull.y = targetDy * 0.002 * (difficulty + 0.5);
        
        const kickRange = 80;
        if (Math.hypot(targetDx, targetDy) < kickRange && enemy.kickCooldown === 0 && Math.random() < 0.1 + difficulty * 0.2) {
            if (!enemy.isKicking) playSound('whoosh');
            updatedKite.isKicking = true;
            updatedKite.kickCooldown = 180 - difficulty * 60;
        } else if (enemy.kickCooldown < 160) {
            updatedKite.isKicking = false;
        }
    } else {
        updatedKite.aiState = 'roaming';
        updatedKite.targetId = null;
        updatedKite.isKicking = false;
    }

    return { aiPull, updatedKite };
};


export const updateCleverAI = (enemy: Kite, player: PlayerKiteInfo, context: AIContext): AIUpdateResult => {
    const { difficulty, playSound } = context;
    let aiPull: Vector2D = { x: 0, y: 0 };
    let updatedKite: Partial<Kite> = {};
    
    if (enemy.aiState !== 'attacking') {
        const playerDist = Math.hypot(enemy.pos.x - player.pos.x, enemy.pos.y - player.pos.y);
        const detectionRange = 150 + difficulty * 50;
        if (playerDist < detectionRange && !player.isCut) {
            updatedKite.aiState = 'attacking';
            updatedKite.targetId = player.id;
        }
    }

    if (updatedKite.aiState === 'attacking' || enemy.aiState === 'attacking') {
        // Once clever attacks, it behaves like aggressive
        const aggressiveResult = updateAggressiveAI(enemy, player, context);
        aiPull = aggressiveResult.aiPull;
        updatedKite = { ...updatedKite, ...aggressiveResult.updatedKite };
    } else {
         updatedKite.isKicking = false;
    }

    return { aiPull, updatedKite };
};


export const updatePeacefulAI = (enemy: Kite, player: PlayerKiteInfo, context: AIContext): AIUpdateResult => {
    let aiPull: Vector2D = { x: 0, y: 0 };
    let updatedKite: Partial<Kite> = { isKicking: false };

    const playerDist = Math.hypot(enemy.pos.x - player.pos.x, enemy.pos.y - player.pos.y);
    const fleeRange = 180;

    if (playerDist < fleeRange && !player.isCut) {
        updatedKite.aiState = 'fleeing';
        const fleeDx = enemy.pos.x - player.pos.x;
        const fleeDy = enemy.pos.y - player.pos.y;
        aiPull = { x: fleeDx * 0.003, y: fleeDy * 0.003 };
    } else {
        updatedKite.aiState = 'roaming';
    }

    return { aiPull, updatedKite };
};
