import type { Kite, Vector2D, PlayerKiteInfo } from '../types';
import { updateAggressiveAI, updateCleverAI, updatePeacefulAI } from './behaviors';

interface AIContext {
    difficulty: number;
    canvasWidth: number;
    canvasHeight: number;
    playSound: (sound: string) => void;
}

interface AIUpdate {
    pull: Vector2D;
    boundary: Vector2D;
}

export const updateKiteAI = (enemy: Kite, player: PlayerKiteInfo, context: AIContext): AIUpdate => {
    // 1. Common pre-AI logic (e.g., update cooldowns)
    enemy.kickCooldown = Math.max(0, enemy.kickCooldown - 1);

    // 2. Determine behavior and get pull force & state changes
    let behaviorResult;
    switch (enemy.aiPersonality) {
        case 'peaceful':
            behaviorResult = updatePeacefulAI(enemy, player, context);
            break;
        case 'aggressive':
            behaviorResult = updateAggressiveAI(enemy, player, context);
            break;
        case 'clever':
            behaviorResult = updateCleverAI(enemy, player, context);
            break;
        default:
             behaviorResult = { aiPull: {x: 0, y: 0}, updatedKite: {} };
    }

    // Apply state changes from behavior function
    Object.assign(enemy, behaviorResult.updatedKite);
    let aiPull = behaviorResult.aiPull;

    // 3. Handle common 'roaming' state if no other action was taken
    if (enemy.aiState === 'roaming') {
        const safeMargin = 100;
        if (!enemy.roamTarget || Math.hypot(enemy.pos.x - enemy.roamTarget.x, enemy.pos.y - enemy.roamTarget.y) < 100) {
            enemy.roamTarget = {
                x: Math.random() * (context.canvasWidth - safeMargin * 2) + safeMargin,
                y: Math.random() * (context.canvasHeight - safeMargin * 2) + safeMargin
            };
        }
        aiPull.x += (enemy.roamTarget.x - enemy.pos.x) * 0.0015;
        aiPull.y += (enemy.roamTarget.y - enemy.pos.y) * 0.0015;
    }

    // 4. Calculate boundary avoidance force
    const safeMargin = 100;
    let boundaryForce = { x: 0, y: 0 };
    if (enemy.pos.x < safeMargin) boundaryForce.x = (safeMargin - enemy.pos.x) * 0.05;
    if (enemy.pos.x > context.canvasWidth - safeMargin) boundaryForce.x = (context.canvasWidth - safeMargin - enemy.pos.x) * 0.05;
    if (enemy.pos.y < safeMargin) boundaryForce.y = (safeMargin - enemy.pos.y) * 0.05;
    if (enemy.pos.y > context.canvasHeight - safeMargin) boundaryForce.y = (context.canvasHeight - safeMargin - enemy.pos.y) * 0.05;
    
    return {
        pull: aiPull,
        boundary: boundaryForce,
    };
};
